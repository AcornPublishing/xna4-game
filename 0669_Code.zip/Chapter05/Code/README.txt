This archive contains the Asteroid Belt Assault game as it is at the end of Chapter 5. 
Extract the archive to your Visual Studio 2010 Projects folder and open the .SLN file with
Visual Studio 2010 Express.
