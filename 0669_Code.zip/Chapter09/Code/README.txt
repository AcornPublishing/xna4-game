This archive contains the Gemstone Hunter game as it is at the end of Chapter 9. 
Extract the archive to your Visual Studio 2010 Projects folder and open the .SLN file with
Visual Studio 2010 Express.

This project contains the player and enemy sprites from the XNA Platform Starter Kit, provided
with XNA Game Studio by Microsoft. For more information about the XNA Starter Kits, see the
Creators Club Web Site at http://creators.xna.com