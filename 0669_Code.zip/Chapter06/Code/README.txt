This archive contains the Robot Rampage game as it is at the end of Chapter 6. 
Extract the archive to your Visual Studio 2010 Projects folder and open the .SLN file with
Visual Studio 2010 Express.
